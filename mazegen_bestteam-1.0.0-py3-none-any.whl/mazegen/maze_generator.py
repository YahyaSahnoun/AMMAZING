import random
from typing import List
from mazegen.cell import Cell
from mazegen.maze_utils import get_neighbors


class MazeGenerator:
    def __init__(self, width: int, height: int, perfect: bool = True,
                 seed: int | None = None):
        self.width = width
        self.height = height
        self.perfect = perfect
        self.seed = seed
        if seed is not None:
            random.seed(seed)

        self.grid: List[List[Cell]] = self.create_grid()
        self.pattern_42 = set()

    def create_grid(self) -> List[List[Cell]]:
        return [[Cell(x, y) for x in range(self.width)] for y in range(
            self.height)]

    def init_42_pattern(self):
        if self.width < 12 or self.height < 12:
            print(f"Grid too small ({self.width}x{self.height})",
                  "– skipping 42 pattern")
            return

        cx, cy = self.width // 2, self.height // 2

        pattern = [
            "01000111 ",
            "01000  1 ",
            "01110111 ",
            "000101   ",
            "00010111 ",
        ]

        start_x = cx - 5
        start_y = cy - 2

        for dy, row in enumerate(pattern):
            for dx, val in enumerate(row):
                if val == "1":
                    x = start_x + dx
                    y = start_y + dy
                    if 0 <= x < self.width and 0 <= y < self.height:
                        self.pattern_42.add((x, y))
                        self.grid[y][x].passable = False

    def generate_maze(self) -> List[List[Cell]]:
        if self.seed is not None:
            random.seed(self.seed)

        self.init_42_pattern()

        for row in self.grid:
            for cell in row:
                cell.visited = False
                cell.north = cell.south = cell.east = cell.west = True

                if not hasattr(cell, "passable"):
                    cell.passable = True

        entry = (0, 0)
        exit_ = (self.width - 1, self.height - 1)
        if hasattr(self, "entry_override"):
            entry = self.entry_override
        if hasattr(self, "exit_override"):
            exit_ = self.exit_override

        if entry in self.pattern_42:
            raise ValueError("This ENTRY is inside the 42 pattern!")
        if exit_ in self.pattern_42:
            raise ValueError("This EXIT is inside the 42 pattern!")

        stack = []

        current = self.grid[0][0]
        if not current.passable:
            raise ValueError("Start is inside blocked 42 pattern")

        current.visited = True

        while True:
            neighbors = [
                n for n in get_neighbors(self.grid, current)
                if n.passable and not n.visited
            ]

            if neighbors:
                nxt = random.choice(neighbors)
                current.remove_wall(nxt)
                stack.append(current)
                nxt.visited = True
                current = nxt
            elif stack:
                current = stack.pop()
            else:
                break

        if not self.perfect:
            self._add_loops()

        return self.grid

    def _add_loops(self) -> None:
        for _ in range((self.width * self.height) // 10):
            x = random.randint(0, self.width - 2)
            y = random.randint(0, self.height - 2)

            cell = self.grid[y][x]
            neighbor = self.grid[y][x + 1]

            if cell.passable and neighbor.passable:
                cell.remove_wall(neighbor)

    def validate_maze(self) -> bool:
        return True
